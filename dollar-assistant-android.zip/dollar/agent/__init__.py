"""
Dollar AI Voice Assistant
A fully local, always-running AI voice assistant.
"""

__version__ = "1.0.0"

