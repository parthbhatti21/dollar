========================================
Dollar Assistant - Android Package
========================================

This package contains all files needed to run Dollar Assistant on Android.

INSTALLATION:
1. Extract this ZIP file to your Android device
2. Follow the instructions in ANDROID_INSTALLATION.md
3. Recommended: Use Termux app for best results

QUICK START (Termux):
1. Install Termux from F-Droid or Play Store
2. In Termux, run:
   pkg update && pkg upgrade
   pkg install python python-pip
   pkg install portaudio
   
3. Navigate to this folder:
   cd /sdcard/Download/dollar  # or wherever you extracted
   
4. Setup Python environment:
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   
5. Run:
   cd agent
   python main.py

IMPORTANT NOTES:
- Wake word files (.ppn) are macOS-specific
- For Android, you may need to download Android versions from Picovoice
- Or use Simple VAD instead (configure in config.yaml)
- Grant microphone permission when prompted
- Disable battery optimization for continuous operation

For detailed instructions, see ANDROID_INSTALLATION.md
