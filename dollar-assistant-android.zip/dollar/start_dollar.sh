#!/data/data/com.termux/files/usr/bin/bash
# Dollar Assistant startup script for Termux

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Activate virtual environment if it exists
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

# Run Dollar Assistant
cd agent
python main.py
